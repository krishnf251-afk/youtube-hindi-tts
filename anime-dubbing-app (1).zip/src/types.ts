export interface UserSession {
  uid: string;
  email: string;
  name: string;
  role: 'Leader' | 'Acting Leader' | 'Officer' | 'Common User';
  isOwner: boolean;
}

export interface VideoInfo {
  videoId: string;
  fingerprint: string;
  title: string;
  durationSeconds: number;
  durationFormatted: string;
  thumbnailUrl: string;
  sourcePlatform: string;
  detectedLanguage: string;
}

export interface DubChunk {
  chunkIndex: number;
  range: string;
  durationSeconds: number;
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED';
  outputPath?: string;
}

export interface DubbingJob {
  jobId: string;
  uid: string;
  role: string;
  mode: 'MODE_A_FULL_MP4' | 'MODE_B_AUDIO_ONLY';
  engineUsed: 'Fast Mode' | 'Pro Mode';
  videoInfo: VideoInfo;
  totalChunks: number;
  currentChunkIndex: number;
  chunks: DubChunk[];
  overallProgressPercent: number;
  status: 'INIT' | 'CONFIRMED' | 'PROCESSING' | 'COMPLETED' | 'FAILED';
  outputFileUrl?: string;
  bgmTrackName?: string;
}

export interface AudioMixerState {
  enabled: boolean;
  origVol: number;
  dubVol: number;
  bgmVol: number;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  type: 'INFO' | 'SUCCESS' | 'WARN' | 'ERROR' | 'SYSTEM';
  message: string;
}
