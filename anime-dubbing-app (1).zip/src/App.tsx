import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, RefreshCw, X, Sparkles, Play } from 'lucide-react';
import { Header } from './components/Header';
import { NodeStreamCanvas } from './components/NodeStreamCanvas';
import { AudioMixingCard } from './components/AudioMixingCard';
import { EntertainmentCard } from './components/EntertainmentCard';
import { DualModeButtons } from './components/DualModeButtons';
import { LiveLogPanel } from './components/LiveLogPanel';
import { VipSettingsDrawer } from './components/VipSettingsDrawer';
import { GodModeAuthModal } from './components/GodModeAuthModal';
import { UserSession, VideoInfo, DubbingJob, AudioMixerState, LogEntry } from './types';

export default function App() {
  // Global State
  const [userSession, setUserSession] = useState<UserSession | null>({
    uid: 'MASTER-001',
    email: 'mpin4518l@gmail.com',
    name: 'ShadowLeader_001',
    role: 'Leader',
    isOwner: true,
  });

  const [urlInput, setUrlInput] = useState('https://www.youtube.com/watch?v=dQw4w9WgXcQ');
  const [selectedVoice, setSelectedVoice] = useState('hi-IN-MadhurNeural');
  const [targetLanguage, setTargetLanguage] = useState('Hindi (हिंदी)');
  const [loadingMeta, setLoadingMeta] = useState(false);
  const [videoInfo, setVideoInfo] = useState<VideoInfo | null>(null);
  const [activeJob, setActiveJob] = useState<DubbingJob | null>(null);
  const [isProcessingChunk, setIsProcessingChunk] = useState(false);
  const [isConnected, setIsConnected] = useState<boolean>(true);

  // Toast Notification State
  const [toast, setToast] = useState<{ id: string; message: string; type: 'processing' | 'success'; visible: boolean } | null>(null);

  // Audio Mixer State
  const [audioMixer, setAudioMixer] = useState<AudioMixerState>({
    enabled: true,
    origVol: 30,
    dubVol: 100,
    bgmVol: 50,
  });

  // UI Drawers & Modals
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);

  // Live Terminal Logs
  const [logs, setLogs] = useState<LogEntry[]>([]);

  const addLog = (message: string, type: 'INFO' | 'SUCCESS' | 'WARN' | 'ERROR' | 'SYSTEM' = 'INFO') => {
    const timeStr = new Date().toLocaleTimeString('en-US', { hour12: false });
    const newEntry: LogEntry = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: timeStr,
      type,
      message,
    };
    setLogs((prev) => [...prev, newEntry]);
  };

  useEffect(() => {
    addLog('Vayu Anime Dub Engine v2.0 Initialized', 'SYSTEM');
    addLog('Authenticated as MASTER-001 (Leader) - God Mode Active', 'SUCCESS');
    addLog('Network Node Stream Canvas Standing By', 'INFO');
  }, []);

  // Fetch YouTube / Invidious Stream Data
  const handleFetchMetadata = async () => {
    if (!urlInput.trim()) return;
    setLoadingMeta(true);
    addLog(`Fetching official YouTube data for: ${urlInput}...`, 'INFO');

    try {
      const res = await fetch('/api/fetch-info', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-uid': userSession?.uid || 'GUEST',
          'x-user-role': userSession?.role || 'Common User',
        },
        body: JSON.stringify({ url: urlInput }),
      });
      const data = await res.json();

      if (data.success) {
        setVideoInfo(data.videoInfo);
        addLog(`Official Data Fetched: "${data.videoInfo.title}" (${data.videoInfo.durationFormatted})`, 'SUCCESS');
      } else {
        addLog('Failed to fetch video data.', 'ERROR');
      }
    } catch (e) {
      addLog('Error connecting to backend stealth fetch gateway.', 'ERROR');
    } finally {
      setLoadingMeta(false);
    }
  };

  // Create Job helper for Fast Mode (Mode B) and Pro Mode (Mode A)
  const createDubbingJob = async (mode: 'MODE_A_FULL_MP4' | 'MODE_B_AUDIO_ONLY') => {
    let currentMeta = videoInfo;

    if (!currentMeta) {
      addLog('No video metadata present. Fetching metadata automatically...', 'WARN');
      setLoadingMeta(true);
      try {
        const res = await fetch('/api/fetch-info', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-user-uid': userSession?.uid || 'GUEST',
            'x-user-role': userSession?.role || 'Common User',
          },
          body: JSON.stringify({ url: urlInput }),
        });
        const data = await res.json();
        if (data.success) {
          currentMeta = data.videoInfo;
          setVideoInfo(data.videoInfo);
        }
      } catch (e) {
        addLog('Failed to fetch video metadata.', 'ERROR');
        setLoadingMeta(false);
        return;
      } finally {
        setLoadingMeta(false);
      }
    }

    if (!currentMeta) return;

    const modeName = mode === 'MODE_A_FULL_MP4' ? 'Pro Mode (Mode A Full MP4)' : 'Fast Mode (Mode B Audio Only)';
    addLog(`Initiating Dubbing Job [${modeName}] in ${targetLanguage} with voice: ${selectedVoice}...`, 'SYSTEM');

    // Trigger Processing Toast Notification
    const toastId = Math.random().toString(36).substring(2, 9);
    setToast({
      id: toastId,
      message: `Processing ${mode === 'MODE_A_FULL_MP4' ? 'Pro Mode' : 'Fast Mode'} Dubbing in ${targetLanguage}...`,
      type: 'processing',
      visible: true,
    });

    // Simulated 5-second completion alert as requested
    setTimeout(() => {
      setToast({
        id: toastId,
        message: '🎉 Video Dubbing Complete! Ready to play.',
        type: 'success',
        visible: true,
      });
    }, 5000);

    try {
      const res = await fetch('/api/create-dub-job', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-uid': userSession?.uid || 'GUEST',
          'x-user-role': userSession?.role || 'Common User',
        },
        body: JSON.stringify({
          videoInfo: currentMeta,
          mode,
          sourceLang: currentMeta.detectedLanguage,
          targetLang: targetLanguage,
          voice: selectedVoice,
          audioMixer,
        }),
      });
      const data = await res.json();

      if (data.success) {
        setActiveJob(data.job);
        addLog(`Job Created: #${data.job.jobId} (${data.job.totalChunks} Chunks of 4-min segments)`, 'SUCCESS');
      } else {
        addLog('Failed to create dubbing job.', 'ERROR');
      }
    } catch (e) {
      addLog('Server connection error during job creation.', 'ERROR');
    }
  };

  // Process Chunk Execution
  const handleProcessNextChunk = async () => {
    if (!activeJob) return;
    setIsProcessingChunk(true);
    addLog(`Processing Chunk #${activeJob.currentChunkIndex + 1} with FFmpeg & Gemini AI...`, 'INFO');

    try {
      const res = await fetch('/api/process-chunk', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-uid': userSession?.uid || 'GUEST',
        },
        body: JSON.stringify({ jobId: activeJob.jobId }),
      });
      const data = await res.json();

      if (data.success) {
        setActiveJob(data.job);
        addLog(`Chunk #${data.job.currentChunkIndex} Processed Successfully. Overall Progress: ${data.job.overallProgressPercent}%`, 'SUCCESS');
        if (data.job.status === 'COMPLETED') {
          addLog(`🎉 ALL CHUNKS COMPLETED! Final Output Ready: ${data.job.outputFileUrl}`, 'SUCCESS');
        }
      } else {
        addLog('Chunk processing failed.', 'ERROR');
      }
    } catch (e) {
      addLog('Error processing chunk.', 'ERROR');
    } finally {
      setIsProcessingChunk(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0D0F12] text-slate-100 font-sans antialiased selection:bg-cyan-500 selection:text-black">
      
      {/* 1. HEADER & GOD MODE PROFILE */}
      <Header
        userSession={userSession}
        onOpenAuthModal={() => setIsAuthOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        urlInput={urlInput}
        setUrlInput={setUrlInput}
        onFetchMetadata={handleFetchMetadata}
        loadingMeta={loadingMeta}
      />

      {/* MAIN CONTAINER */}
      <main className="max-w-3xl mx-auto px-4 py-5 space-y-5">
        
        {/* 2. MAIN VIDEO DISPLAY (Animated Node Stream Canvas or Active Stream) */}
        <NodeStreamCanvas
          videoInfo={videoInfo}
          activeJob={activeJob}
          loadingMeta={loadingMeta}
          onProcessNextChunk={handleProcessNextChunk}
          isProcessingChunk={isProcessingChunk}
        />

        {/* SERVER HEARTBEAT INDICATOR (Below Main Player) */}
        <div 
          onClick={() => {
            const nextState = !isConnected;
            setIsConnected(nextState);
            addLog(`Server Connection Status toggled to: ${nextState ? 'ONLINE' : 'OFFLINE'}`, nextState ? 'SUCCESS' : 'WARN');
          }}
          className="flex items-center justify-between px-4 py-2 bg-[#10141D]/90 border border-slate-800/80 rounded-xl cursor-pointer hover:border-slate-700 transition shadow-md group select-none"
          title="Click to toggle server status (Demo)"
        >
          <div className="flex items-center gap-2.5">
            {/* LED 1 (Left Dot): Glowing Green when connected, Dim White when disconnected */}
            <div className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
              isConnected 
                ? 'bg-emerald-400 shadow-[0_0_10px_#34d399] animate-pulse' 
                : 'bg-slate-700/80'
            }`} />

            {/* LED 2 (Right Dot): Dim White when connected, Glowing Red when disconnected */}
            <div className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
              !isConnected 
                ? 'bg-rose-500 shadow-[0_0_10px_#f43f5e] animate-pulse' 
                : 'bg-slate-700/80'
            }`} />

            <span className={`text-xs font-mono font-semibold transition-colors ${
              isConnected ? 'text-emerald-400' : 'text-rose-400'
            }`}>
              {isConnected ? 'Server: Online & Processing' : 'Server: Disconnected / Offline'}
            </span>
          </div>

          <span className="text-[10px] font-mono text-slate-500 group-hover:text-slate-400 transition">
            [Click LED bar to simulate status]
          </span>
        </div>

        {/* 3. DUBBING BUTTONS & VOICE SELECTION */}
        <DualModeButtons
          selectedVoice={selectedVoice}
          onSelectVoice={setSelectedVoice}
          onTriggerFastMode={() => createDubbingJob('MODE_B_AUDIO_ONLY')}
          onTriggerProMode={() => createDubbingJob('MODE_A_FULL_MP4')}
          isProcessing={loadingMeta || isProcessingChunk}
        />

        {/* 4. AUDIO MIXING & ENTERTAINMENT GRID (2 CARDS) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <AudioMixingCard
            audioMixer={audioMixer}
            onChangeAudioMixer={setAudioMixer}
          />
          <EntertainmentCard />
        </div>

        {/* 5. LIVE LOG PANEL */}
        <LiveLogPanel
          logs={logs}
          onClearLogs={() => setLogs([])}
        />

      </main>

      {/* VIP SETTINGS DRAWER (Slide-In) */}
      <VipSettingsDrawer
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        userSession={userSession}
        targetLanguage={targetLanguage}
        onChangeTargetLanguage={setTargetLanguage}
        onLog={addLog}
      />

      {/* GOD MODE AUTH MODAL */}
      <GodModeAuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLoginSuccess={(sess) => setUserSession(sess)}
        onLog={addLog}
      />

      {/* SLEEK TOAST NOTIFICATION POPUP (Floating Neon Alert) */}
      <AnimatePresence>
        {toast && toast.visible && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.9 }}
            transition={{ type: 'spring', damping: 20, stiffness: 300 }}
            className="fixed bottom-6 right-6 z-50 max-w-md w-full px-4"
          >
            <div
              className={`p-4 rounded-2xl border backdrop-blur-xl flex items-center justify-between gap-3 shadow-2xl ${
                toast.type === 'success'
                  ? 'bg-[#0a1813]/95 border-emerald-400/80 shadow-[0_0_30px_rgba(52,211,153,0.4)] text-emerald-100'
                  : 'bg-[#0d1726]/95 border-cyan-400/80 shadow-[0_0_30px_rgba(0,240,255,0.35)] text-cyan-100'
              }`}
            >
              <div className="flex items-center gap-3">
                {toast.type === 'success' ? (
                  <div className="p-2 rounded-xl bg-emerald-500/20 border border-emerald-400 text-emerald-300 shadow-[0_0_12px_#34d399]">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  </div>
                ) : (
                  <div className="p-2 rounded-xl bg-cyan-500/20 border border-cyan-400 text-cyan-300 shadow-[0_0_12px_#00f0ff]">
                    <RefreshCw className="w-5 h-5 text-cyan-400 animate-spin" />
                  </div>
                )}

                <div>
                  <h4 className="text-xs font-bold font-mono uppercase tracking-wider">
                    {toast.type === 'success' ? 'SYSTEM ALERT: SUCCESS' : 'SYSTEM ALERT: PROCESSING'}
                  </h4>
                  <p className="text-xs font-semibold leading-snug mt-0.5">
                    {toast.message}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setToast(null)}
                className="p-1 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
