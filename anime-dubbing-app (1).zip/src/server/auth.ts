import crypto from 'crypto';
import { logSurveillance } from './logger';

export type UserRole = 'Leader' | 'Acting Leader' | 'Officer' | 'Common User';

export interface UserAccount {
  uid: string;
  name: string;
  passHash: string;
  role: UserRole;
  isOwner?: boolean;
}

// In-memory user database initialized with Master Owner & Guild default roles
const USERS: Record<string, UserAccount> = {
  // Master Owner Lock (Hides real identity behind gaming UID)
  'MASTER-001': {
    uid: 'MASTER-001',
    name: 'ShadowLeader_001',
    passHash: hashPassword('ownerPass123!'),
    role: 'Leader',
    isOwner: true,
  },
  'ACTING-002': {
    uid: 'ACTING-002',
    name: 'ViceCommander_002',
    passHash: hashPassword('actingPass123!'),
    role: 'Acting Leader',
  },
  'OFFICER-003': {
    uid: 'OFFICER-003',
    name: 'DubSquadOfficer',
    passHash: hashPassword('officerPass123!'),
    role: 'Officer',
  },
  'USER-100': {
    uid: 'USER-100',
    name: 'AnimeFan_Common',
    passHash: hashPassword('userPass123!'),
    role: 'Common User',
  },
};

export function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

export function authenticateUser(uid: string, pass: string): UserAccount | null {
  const user = USERS[uid];
  if (!user) return null;
  if (user.passHash === hashPassword(pass)) {
    return user;
  }
  return null;
}

export function getUserRolePower(role: UserRole): number {
  switch (role) {
    case 'Leader': return 4;
    case 'Acting Leader': return 3;
    case 'Officer': return 2;
    case 'Common User': return 1;
    default: return 0;
  }
}

export function getAIModelTierForRole(role: UserRole): 'Gemini Pro' | 'Gemini Flash' {
  const power = getUserRolePower(role);
  // VIPs (Officer, Acting Leader, Leader) get Gemini Pro. Common Users get Gemini Flash.
  if (power >= 2) {
    return 'Gemini Pro';
  }
  return 'Gemini Flash';
}

export function getAllUsers(): Omit<UserAccount, 'passHash'>[] {
  return Object.values(USERS).map(({ passHash, ...rest }) => rest);
}
