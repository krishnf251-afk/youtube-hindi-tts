import fs from 'fs';
import path from 'path';

const LOG_DIR = path.join(process.cwd(), 'logs');

// Ensure log directory exists
if (!fs.existsSync(LOG_DIR)) {
  fs.mkdirSync(LOG_DIR, { recursive: true });
}

const ERR_LOG_FILE = path.join(LOG_DIR, 'backend_errors.log');
const SURVEILLANCE_LOG_FILE = path.join(LOG_DIR, 'surveillance.log');

export function logError(error: any, context: string = 'GENERAL') {
  const timestamp = new Date().toISOString();
  const errorMessage = error instanceof Error ? error.stack || error.message : String(error);
  const logEntry = `[${timestamp}] [${context}] ${errorMessage}\n`;
  
  fs.appendFile(ERR_LOG_FILE, logEntry, (err) => {
    if (err) console.error('Failed to write to error log:', err);
  });
  console.error(`[SILENT LOGGED - ${context}]:`, error?.message || error);
}

export function logSurveillance(data: {
  uid: string;
  role: string;
  ip?: string;
  action: string;
  videoUrl?: string;
  mode?: string;
  status: string;
  details?: string;
}) {
  const timestamp = new Date().toISOString();
  const logEntry = JSON.stringify({
    timestamp,
    uid: data.uid || 'GUEST',
    role: data.role || 'Common User',
    ip: data.ip || '127.0.0.1',
    action: data.action,
    videoUrl: data.videoUrl || '',
    mode: data.mode || '',
    status: data.status,
    details: data.details || '',
  }) + '\n';

  fs.appendFile(SURVEILLANCE_LOG_FILE, logEntry, (err) => {
    if (err) console.error('Failed to write surveillance log:', err);
  });
}

export function getSurveillanceLogs(limit: number = 50): any[] {
  try {
    if (!fs.existsSync(SURVEILLANCE_LOG_FILE)) return [];
    const content = fs.readFileSync(SURVEILLANCE_LOG_FILE, 'utf-8');
    const lines = content.trim().split('\n').filter(Boolean);
    return lines.slice(-limit).map(line => {
      try {
        return JSON.parse(line);
      } catch {
        return { raw: line };
      }
    }).reverse();
  } catch (err) {
    logError(err, 'READ_SURVEILLANCE_LOGS');
    return [];
  }
}

export function getErrorLogs(limit: number = 50): string[] {
  try {
    if (!fs.existsSync(ERR_LOG_FILE)) return [];
    const content = fs.readFileSync(ERR_LOG_FILE, 'utf-8');
    const lines = content.trim().split('\n').filter(Boolean);
    return lines.slice(-limit).reverse();
  } catch (err) {
    console.error('Failed to read error logs:', err);
    return [];
  }
}
