import fs from 'fs';
import path from 'path';
import { logSurveillance, logError } from './logger';
import { DubbingJob } from './dubbingEngine';

const DISK_CACHE_DIR = path.join(process.cwd(), 'cache', 'completed');

if (!fs.existsSync(DISK_CACHE_DIR)) {
  fs.mkdirSync(DISK_CACHE_DIR, { recursive: true });
}

// Tier 1: In-Memory Fast LRU Cache
const MEMORY_CACHE: Record<string, DubbingJob> = {};

// Feature 11 & 13: Look up double-tier cache by Video ID or Fingerprint
export function checkCacheByFingerprintOrId(videoIdOrFingerprint: string): DubbingJob | null {
  // Check Tier 1 Memory Cache
  for (const key in MEMORY_CACHE) {
    const job = MEMORY_CACHE[key];
    if (job.videoInfo.videoId === videoIdOrFingerprint || job.videoInfo.fingerprint === videoIdOrFingerprint) {
      if (job.status === 'COMPLETED') {
        return job;
      }
    }
  }

  // Check Tier 2 Disk Cache
  try {
    const diskPath = path.join(DISK_CACHE_DIR, `${videoIdOrFingerprint}.json`);
    if (fs.existsSync(diskPath)) {
      const data = fs.readFileSync(diskPath, 'utf-8');
      const job: DubbingJob = JSON.parse(data);
      // Re-populate Tier 1
      MEMORY_CACHE[job.jobId] = job;
      return job;
    }
  } catch (err) {
    logError(err, 'DISK_CACHE_CHECK');
  }

  return null;
}

export function saveCompletedJobToCache(job: DubbingJob) {
  MEMORY_CACHE[job.jobId] = job;
  try {
    const diskPath = path.join(DISK_CACHE_DIR, `${job.jobId}.json`);
    const fpDiskPath = path.join(DISK_CACHE_DIR, `${job.videoInfo.fingerprint}.json`);
    const content = JSON.stringify(job, null, 2);
    
    fs.writeFileSync(diskPath, content, 'utf-8');
    fs.writeFileSync(fpDiskPath, content, 'utf-8');
  } catch (err) {
    logError(err, 'SAVE_JOB_CACHE');
  }
}

// Feature 12: Smart Video Sharing (Instant transfer between Guild users)
export function createShareToken(jobId: string, senderUid: string, receiverUid: string) {
  const shareToken = `share_${jobId.substring(0, 8)}_${Date.now()}`;
  
  logSurveillance({
    uid: senderUid,
    role: 'Guild Member',
    action: 'SHARE_DUBBED_VIDEO',
    videoUrl: jobId,
    status: 'SUCCESS',
    details: `Transferred dubbed video to ${receiverUid} via token ${shareToken}`,
  });

  return {
    shareToken,
    shareUrl: `/api/shared-dub/${shareToken}`,
    jobId,
    senderUid,
    receiverUid,
    createdAt: new Date().toISOString(),
  };
}
