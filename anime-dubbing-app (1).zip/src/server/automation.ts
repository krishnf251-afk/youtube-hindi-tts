import fs from 'fs';
import path from 'path';
import os from 'os';
import { logError, logSurveillance } from './logger';

const TEMP_DIR = path.join(process.cwd(), 'temp');
const CACHE_DIR = path.join(process.cwd(), 'cache');

// Queue of scheduled links
const SCHEDULED_QUEUE: { id: string; url: string; mode: string; addedBy: string; scheduledTime: string }[] = [];

// Feature 23: Auto-Scheduler Cron simulation
export function addScheduledDubTask(url: string, mode: string, addedBy: string, minutesFromNow: number = 0) {
  const scheduledTime = new Date(Date.now() + minutesFromNow * 60000).toISOString();
  const id = `sched_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
  
  SCHEDULED_QUEUE.push({ id, url, mode, addedBy, scheduledTime });
  
  logSurveillance({
    uid: addedBy,
    role: 'User',
    action: 'SCHEDULE_AUTO_DUB',
    videoUrl: url,
    mode,
    status: 'QUEUED',
    details: `Scheduled for ${scheduledTime}`,
  });

  return { id, url, mode, scheduledTime, queuePosition: SCHEDULED_QUEUE.length };
}

export function getScheduledQueue() {
  return SCHEDULED_QUEUE;
}

// Feature 24: 12-Hour Auto-Cleaner
export function run12HourAutoCleaner(): { deletedCount: number; freedMb: number } {
  let deletedCount = 0;
  let totalBytesFreed = 0;
  const TWELVE_HOURS_MS = 12 * 60 * 60 * 1000;
  const now = Date.now();

  const cleanDirectory = (dirPath: string) => {
    if (!fs.existsSync(dirPath)) return;
    try {
      const files = fs.readdirSync(dirPath);
      for (const file of files) {
        const filePath = path.join(dirPath, file);
        const stats = fs.statSync(filePath);
        if (stats.isFile()) {
          const fileAge = now - stats.mtimeMs;
          if (fileAge > TWELVE_HOURS_MS) {
            totalBytesFreed += stats.size;
            fs.unlinkSync(filePath);
            deletedCount++;
          }
        }
      }
    } catch (err) {
      logError(err, 'AUTO_CLEANER');
    }
  };

  cleanDirectory(TEMP_DIR);
  cleanDirectory(CACHE_DIR);

  const freedMb = Math.round((totalBytesFreed / (1024 * 1024)) * 100) / 100;
  
  logSurveillance({
    uid: 'SYSTEM_CRON',
    role: 'Leader',
    action: 'AUTO_CLEANER_12H',
    status: 'SUCCESS',
    details: `Cleaned ${deletedCount} files older than 12h, freed ${freedMb} MB`,
  });

  return { deletedCount, freedMb };
}

// Feature 25: Traffic / Load Indicator API (Server Load: Green, Yellow, Red)
export function calculateServerLoad(): {
  status: 'GREEN' | 'YELLOW' | 'RED';
  loadPercent: number;
  cpuCount: number;
  freeMemoryMB: number;
  activeQueueJobs: number;
  statusLabel: string;
} {
  const freeMemMB = Math.round(os.freemem() / (1024 * 1024));
  const totalMemMB = Math.round(os.totalmem() / (1024 * 1024));
  const memoryUsagePercent = Math.round(((totalMemMB - freeMemMB) / totalMemMB) * 100);
  
  const activeQueueJobs = SCHEDULED_QUEUE.length;

  let status: 'GREEN' | 'YELLOW' | 'RED' = 'GREEN';
  let statusLabel = 'सर्वसामान्य लोड (सर्वर सही चल रहा है)';

  if (memoryUsagePercent > 80 || activeQueueJobs > 10) {
    status = 'RED';
    statusLabel = 'उच्च लोड! (Queue में अधिक रिक्वेस्ट्स हैं)';
  } else if (memoryUsagePercent > 50 || activeQueueJobs > 3) {
    status = 'YELLOW';
    statusLabel = 'मध्यम लोड (सामान्य प्रतीक्षा समय)';
  }

  return {
    status,
    loadPercent: memoryUsagePercent,
    cpuCount: os.cpus().length || 4,
    freeMemoryMB: freeMemMB,
    activeQueueJobs,
    statusLabel,
  };
}

// Start background cron loops
setInterval(() => {
  run12HourAutoCleaner();
}, 12 * 60 * 60 * 1000); // 12 Hours

setInterval(() => {
  // Check scheduled tasks
  const nowISO = new Date().toISOString();
  for (let i = SCHEDULED_QUEUE.length - 1; i >= 0; i--) {
    if (SCHEDULED_QUEUE[i].scheduledTime <= nowISO) {
      const task = SCHEDULED_QUEUE.splice(i, 1)[0];
      logSurveillance({
        uid: task.addedBy,
        role: 'User',
        action: 'EXECUTE_SCHEDULED_DUB',
        videoUrl: task.url,
        mode: task.mode,
        status: 'EXECUTING',
      });
    }
  }
}, 30000); // Every 30s
