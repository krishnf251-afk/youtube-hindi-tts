import { GoogleGenAI } from '@google/genai';
import { logError } from './logger';

let aiClient: GoogleGenAI | null = null;

function getAIClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY || 'MOCK_KEY';
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Feature 7: AI Onboarding Guide Bot for new users
export async function getOnboardingAnswer(userQuery: string, userRole: string = 'Common User') {
  const prompt = `
You are the AI Onboarding Guide Bot for "Anime Dubbing App" (एनिमी डबिंग ऐप).
Target user role: ${userRole}.

Key features to guide the user about:
1. Mode A: Third-party video download + full MP4 dubbing.
2. Mode B: Audio-only stream extraction + Hindi audio dubbing.
3. YouTube Third-Party Bypass: Invidious / Piped / Direct API to avoid YouTube block.
4. Guild Hierarchy: Leader, Acting Leader, Officer (VIP Gemini Pro), Common User (Fast Mode).
5. Fast Mode vs Pro Mode: Model white-labeling.
6. Smart Chunking: 4-5 min chunk rendering with auto-resume.
7. Instant Voice Changer: Convert individual sentences to anime voices.

User Query: "${userQuery}"

Answer concisely in friendly Hindi (हिंदी), welcoming the user and providing clear step-by-step guidance.
`;

  try {
    const ai = getAIClient();
    const res = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
    });
    if (res.text) {
      return res.text;
    }
  } catch (err) {
    logError(err, 'ONBOARDING_BOT');
  }

  return `नमस्कार! एनिमी डबिंग ऐप में आपका स्वागत है। 
आप बिना यूट्यूब ब्लॉक के 2 तरीकों (Mode A - वीडियो + ऑडियो, Mode B - केवल ऑडियो) में जापानी/चाइनीज एनिमी को हिंदी में डब कर सकते हैं।
अगर आप Officer या Leader हैं तो आपको Pro Mode (Gemini Pro) मिलता है, अन्यथा Fast Mode मिलेगा!`;
}
