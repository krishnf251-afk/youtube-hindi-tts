import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Mic, Key, Music, Activity, Shield, Trash2, RotateCcw, CloudUpload, Check, RefreshCw, Globe } from 'lucide-react';
import { UserSession } from '../types';

interface VipSettingsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  userSession: UserSession | null;
  targetLanguage: string;
  onChangeTargetLanguage: (lang: string) => void;
  onLog: (msg: string, type?: 'INFO' | 'SUCCESS' | 'WARN' | 'ERROR' | 'SYSTEM') => void;
}

export const VipSettingsDrawer: React.FC<VipSettingsDrawerProps> = ({
  isOpen,
  onClose,
  userSession,
  targetLanguage,
  onChangeTargetLanguage,
  onLog,
}) => {
  const [geminiKey, setGeminiKey] = useState('');
  const [elevenKey, setElevenKey] = useState('');
  const [bgmPreset, setBgmPreset] = useState('Phonk Beat (Action)');
  const [serverLoad, setServerLoad] = useState<any>(null);
  const [clonedVoiceName, setClonedVoiceName] = useState('');
  const [isRecordingSample, setIsRecordingSample] = useState(false);

  useEffect(() => {
    if (isOpen) {
      fetchServerLoad();
    }
  }, [isOpen]);

  const fetchServerLoad = async () => {
    try {
      const res = await fetch('/api/server-load');
      const data = await res.json();
      if (data.success) setServerLoad(data.loadInfo);
    } catch (e) {}
  };

  const handleClearCache = async () => {
    try {
      const res = await fetch('/api/admin/trigger-cleaner', { method: 'POST' });
      const data = await res.json();
      onLog(`[ADMIN] Server Cache Cleared: ${data.result.deleted_files} files removed, ${data.result.freed_mb}MB freed.`, 'SUCCESS');
      alert(`Cache Cleared! Freed ${data.result.freed_mb}MB`);
    } catch (e) {
      onLog('[ADMIN] Failed to clear server cache.', 'ERROR');
    }
  };

  const handleEmergencyRollback = async () => {
    if (!confirm('Are you sure you want to trigger Emergency Rollback?')) return;
    try {
      const res = await fetch('/api/admin/emergency-escape', {
        method: 'POST',
        headers: { 'x-user-uid': userSession?.uid || 'GUEST' },
      });
      const data = await res.json();
      onLog(`[ADMIN] Emergency Escape Triggered: ${data.message}`, 'WARN');
      alert(data.message);
    } catch (e) {
      onLog('[ADMIN] Emergency Rollback Failed', 'ERROR');
    }
  };

  const handleSyncBackup = async () => {
    try {
      const res = await fetch('/api/admin/backup-sync', {
        method: 'POST',
        headers: { 'x-user-uid': userSession?.uid || 'GUEST' },
      });
      const data = await res.json();
      onLog(`[ADMIN] GitHub & HuggingFace Sync Completed. Commit: ${data.status.githubCommitHash}`, 'SUCCESS');
      alert('GitHub & HuggingFace Mirror Synced!');
    } catch (e) {
      onLog('[ADMIN] Backup Sync Failed', 'ERROR');
    }
  };

  const handleSimulateRecord = () => {
    setIsRecordingSample(true);
    onLog('[VOICE CLONE] Recording 10s voice sample...', 'INFO');
    setTimeout(() => {
      setIsRecordingSample(false);
      setClonedVoiceName('My_Custom_Anime_Voice_v1');
      onLog('[VOICE CLONE] Voice sample processed & cloned successfully!', 'SUCCESS');
    }, 3000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-40"
          />

          {/* Drawer Container */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 h-full w-full max-w-md bg-[#0b0e14] border-l border-slate-800/90 text-white z-50 p-6 overflow-y-auto space-y-6 shadow-2xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h2 className="text-base font-bold tracking-wide flex items-center gap-2">
                <Shield className="w-5 h-5 text-cyan-400" />
                VIP Settings Drawer
              </h2>
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* 0. Multilingual Target Language Dropdown */}
            <div className="space-y-3 bg-[#121620] p-4 rounded-2xl border border-cyan-500/30 shadow-[0_0_15px_rgba(0,240,255,0.1)]">
              <h3 className="text-xs font-bold text-cyan-300 flex items-center gap-2 uppercase tracking-wider">
                <Globe className="w-4 h-4 text-cyan-400 animate-pulse" />
                Target Language
              </h3>
              <p className="text-[11px] text-slate-400">
                Select output translation language for Gemini AI script translation & speech synthesis.
              </p>

              <select
                value={targetLanguage}
                onChange={(e) => {
                  onChangeTargetLanguage(e.target.value);
                  onLog(`Target translation language set to: ${e.target.value}`, 'SYSTEM');
                }}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 cursor-pointer font-sans"
              >
                <option value="Hindi (हिंदी)">Hindi (हिंदी) - Official Default</option>
                <option value="Tamil (தமிழ்)">Tamil (தமிழ்)</option>
                <option value="Telugu (తెలుగు)">Telugu (తెలుగు)</option>
                <option value="Bengali (বাংলা)">Bengali (বাংলা)</option>
                <option value="English (US)">English (US / Global)</option>
                <option value="Spanish (Español)">Spanish (Español)</option>
                <option value="Japanese (日本語)">Japanese (日本語)</option>
                <option value="French (Français)">French (Français)</option>
                <option value="German (Deutsch)">German (Deutsch)</option>
                <option value="Korean (한국어)">Korean (한국어)</option>
              </select>
            </div>

            {/* 1. Voice Cloning Studio */}
            <div className="space-y-3 bg-[#121620] p-4 rounded-2xl border border-slate-800">
              <h3 className="text-xs font-bold text-cyan-300 flex items-center gap-2 uppercase tracking-wider">
                <Mic className="w-4 h-4" />
                Voice Cloning Studio
              </h3>
              <p className="text-[11px] text-slate-400">
                Record or upload a 10-second sample to clone your voice for anime dubbing.
              </p>

              <button
                onClick={handleSimulateRecord}
                disabled={isRecordingSample}
                className="w-full py-2.5 bg-cyan-950 border border-cyan-800 hover:bg-cyan-900 text-cyan-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition"
              >
                {isRecordingSample ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-cyan-400" />
                    Recording Sample (10s)...
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4 text-cyan-400" />
                    Record Mic Sample (10s)
                  </>
                )}
              </button>

              {clonedVoiceName && (
                <div className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 p-2.5 rounded-xl border border-emerald-800/80 flex items-center justify-between">
                  <span>Active Clone: {clonedVoiceName}</span>
                  <Check className="w-4 h-4 text-emerald-400" />
                </div>
              )}
            </div>

            {/* 2. API Keys Management */}
            <div className="space-y-3 bg-[#121620] p-4 rounded-2xl border border-slate-800">
              <h3 className="text-xs font-bold text-cyan-300 flex items-center gap-2 uppercase tracking-wider">
                <Key className="w-4 h-4" />
                API Keys Management
              </h3>

              <div>
                <label className="block text-[11px] font-medium text-slate-300 mb-1">Gemini API Key (Server Override)</label>
                <input
                  type="password"
                  value={geminiKey}
                  onChange={(e) => setGeminiKey(e.target.value)}
                  placeholder="AIzaSy..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-300 mb-1">ElevenLabs / EdgeTTS Key</label>
                <input
                  type="password"
                  value={elevenKey}
                  onChange={(e) => setElevenKey(e.target.value)}
                  placeholder="Optional third-party key..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            {/* 3. BGM Presets */}
            <div className="space-y-3 bg-[#121620] p-4 rounded-2xl border border-slate-800">
              <h3 className="text-xs font-bold text-cyan-300 flex items-center gap-2 uppercase tracking-wider">
                <Music className="w-4 h-4" />
                BGM Presets
              </h3>
              <select
                value={bgmPreset}
                onChange={(e) => setBgmPreset(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="Phonk Beat (Action)">Heavy Phonk Beat (Action Fight)</option>
                <option value="Dramatic Anime OST">Dramatic Anime OST</option>
                <option value="Hype Fight Beat">Hype Anime Battle Beat</option>
                <option value="Silent">None (No BGM)</option>
              </select>
            </div>

            {/* 4. Server Health Radar */}
            <div className="space-y-3 bg-[#121620] p-4 rounded-2xl border border-slate-800">
              <h3 className="text-xs font-bold text-cyan-300 flex items-center gap-2 uppercase tracking-wider">
                <Activity className="w-4 h-4" />
                Server Health Radar
              </h3>
              {serverLoad && (
                <div className="text-xs font-mono space-y-1.5 text-slate-300">
                  <div className="flex justify-between">
                    <span>Server Status:</span>
                    <span className="text-emerald-400 font-bold">{serverLoad.status}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Current Traffic Load:</span>
                    <span className="text-cyan-300 font-bold">{serverLoad.load_percent}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Active FFmpeg Workers:</span>
                    <span className="text-indigo-300 font-bold">4 Threads</span>
                  </div>
                </div>
              )}
            </div>

            {/* 5. ADMIN CONTROLS (VISIBLE ONLY TO MASTER OWNER / GOD MODE) */}
            {userSession?.isOwner && (
              <div className="space-y-3 bg-rose-950/30 border border-rose-800/80 p-4 rounded-2xl">
                <h3 className="text-xs font-bold text-rose-400 flex items-center gap-2 uppercase tracking-wider">
                  <Shield className="w-4 h-4" />
                  Admin Controls (God Mode Active)
                </h3>

                <div className="space-y-2">
                  <button
                    onClick={handleClearCache}
                    className="w-full py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                    Clear Server Cache (12h Cleaner)
                  </button>

                  <button
                    onClick={handleEmergencyRollback}
                    className="w-full py-2 bg-rose-900/60 hover:bg-rose-900 border border-rose-700 text-rose-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Emergency Escape Rollback
                  </button>

                  <button
                    onClick={handleSyncBackup}
                    className="w-full py-2 bg-sky-950 border border-sky-800 hover:bg-sky-900 text-sky-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition"
                  >
                    <CloudUpload className="w-3.5 h-3.5 text-sky-400" />
                    GitHub & HuggingFace Sync
                  </button>
                </div>
              </div>
            )}

          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
