import React, { useState } from 'react';
import { Tv, Radio, Sparkles } from 'lucide-react';

export const EntertainmentCard: React.FC = () => {
  const [selectedStream, setSelectedStream] = useState('https://www.youtube-nocookie.com/embed/jfKfPfyJRdk?autoplay=0');

  const streams = [
    { name: 'Lofi Beats Live', url: 'https://www.youtube-nocookie.com/embed/jfKfPfyJRdk?autoplay=0' },
    { name: 'Anime Fight Scenes', url: 'https://www.youtube-nocookie.com/embed/S2p_P3xZ_mU?autoplay=0' },
    { name: 'Chill Gaming Stream', url: 'https://www.youtube-nocookie.com/embed/5qap5aO4i9A?autoplay=0' },
  ];

  return (
    <div className="bg-[#10141D] border border-slate-800/90 rounded-2xl p-4 space-y-3 shadow-xl relative overflow-hidden flex flex-col justify-between">
      {/* Title & Stream Selector */}
      <div className="flex items-center justify-between z-10">
        <h3 className="text-sm font-bold text-white tracking-wide flex items-center gap-2">
          <Tv className="w-4 h-4 text-cyan-400" />
          Entertainment
        </h3>

        <div className="flex items-center gap-1.5">
          <Radio className="w-3 h-3 text-rose-500 animate-pulse" />
          <span className="text-[10px] font-mono text-rose-400 font-bold uppercase tracking-wider">
            LIVE STREAM
          </span>
        </div>
      </div>

      {/* Embedded Working YouTube iFrame Player */}
      <div className="relative w-full aspect-video sm:h-36 rounded-xl bg-slate-950 border border-slate-800/90 overflow-hidden shadow-inner group">
        <iframe
          src={selectedStream}
          title="Entertainment Stream Player"
          className="w-full h-full border-0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      </div>

      {/* Stream Preset Quick Switch Buttons */}
      <div className="flex items-center justify-between gap-1 z-10">
        {streams.map((s) => (
          <button
            key={s.name}
            onClick={() => setSelectedStream(s.url)}
            className={`flex-1 py-1 px-1.5 rounded-lg text-[10px] font-mono font-medium transition ${
              selectedStream === s.url
                ? 'bg-cyan-950/80 border border-cyan-500 text-cyan-200 shadow-[0_0_8px_rgba(0,240,255,0.3)]'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {s.name}
          </button>
        ))}
      </div>
    </div>
  );
};

