import React, { useEffect, useState } from 'react';
import { Play, Film, CheckCircle, RefreshCw, Cpu, Radio, Sparkles } from 'lucide-react';
import { VideoInfo, DubbingJob } from '../types';

interface NodeStreamCanvasProps {
  videoInfo: VideoInfo | null;
  activeJob: DubbingJob | null;
  loadingMeta: boolean;
  onProcessNextChunk: () => void;
  isProcessingChunk: boolean;
}

export const NodeStreamCanvas: React.FC<NodeStreamCanvasProps> = ({
  videoInfo,
  activeJob,
  loadingMeta,
  onProcessNextChunk,
  isProcessingChunk,
}) => {
  const [nodes, setNodes] = useState<{ id: number; x: number; y: number; r: number; delay: number }[]>([]);

  useEffect(() => {
    // Generate organic network node positions matching reference screenshot
    const generated = [
      { id: 1, x: 22, y: 52, r: 10, delay: 0 },
      { id: 2, x: 32, y: 72, r: 8, delay: 0.5 },
      { id: 3, x: 42, y: 28, r: 7, delay: 1 },
      { id: 4, x: 50, y: 82, r: 9, delay: 1.5 },
      { id: 5, x: 58, y: 52, r: 11, delay: 0.2 },
      { id: 6, x: 68, y: 20, r: 6, delay: 0.8 },
      { id: 7, x: 80, y: 40, r: 8, delay: 1.2 },
      { id: 8, x: 38, y: 35, r: 5, delay: 0.4 },
      { id: 9, x: 74, y: 70, r: 5, delay: 1.6 },
    ];
    setNodes(generated);
  }, []);

  return (
    <div className="relative w-full aspect-video md:aspect-[21/9] max-h-[380px] bg-gradient-to-b from-[#111c35] via-[#0d162a] to-[#0a1020] rounded-2xl border border-sky-900/40 shadow-2xl overflow-hidden flex items-center justify-center">
      {/* Background Subtle Tech Grid */}
      <div 
        className="absolute inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(#00f0ff 1px, transparent 1px)`,
          backgroundSize: '24px 24px'
        }}
      />

      {/* DEFAULT STATE: Animated Network Node Graph */}
      {!videoInfo && !activeJob && (
        <div className="relative w-full h-full flex items-center justify-center">
          {/* Constellation Connecting Lines */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none stroke-sky-400/30">
            <line x1="22%" y1="52%" x2="32%" y2="72%" strokeWidth="1.5" strokeDasharray="4 2" />
            <line x1="22%" y1="52%" x2="42%" y2="28%" strokeWidth="1.5" />
            <line x1="42%" y1="28%" x2="58%" y2="52%" strokeWidth="1.5" />
            <line x1="32%" y1="72%" x2="50%" y2="82%" strokeWidth="1.5" />
            <line x1="50%" y1="82%" x2="58%" y2="52%" strokeWidth="2" stroke="#ffffff" opacity="0.6" />
            <line x1="58%" y1="52%" x2="68%" y2="20%" strokeWidth="1.5" />
            <line x1="68%" y1="20%" x2="80%" y2="40%" strokeWidth="1.5" />
            <line x1="58%" y1="52%" x2="80%" y2="40%" strokeWidth="1.5" strokeDasharray="3 3" />
            <line x1="80%" y1="40%" x2="74%" y2="70%" strokeWidth="1.5" />
          </svg>

          {/* Node Circles */}
          {nodes.map((node) => (
            <div
              key={node.id}
              className="absolute transform -translate-x-1/2 -translate-y-1/2"
              style={{ left: `${node.x}%`, top: `${node.y}%` }}
            >
              <div 
                className="rounded-full bg-white shadow-[0_0_12px_#00f0ff] animate-pulse"
                style={{
                  width: `${node.r * 2}px`,
                  height: `${node.r * 2}px`,
                  animationDelay: `${node.delay}s`,
                  boxShadow: '0 0 15px rgba(255, 255, 255, 0.9), 0 0 25px rgba(0, 240, 255, 0.6)'
                }}
              />
            </div>
          ))}

          {/* Glowing Center Waiting Text Badge */}
          <div className="z-10 bg-[#080d1a]/85 border border-sky-500/30 backdrop-blur-md px-6 py-2.5 rounded-xl shadow-[0_0_30px_rgba(0,180,255,0.2)] flex items-center gap-3">
            <Radio className="w-4 h-4 text-sky-400 animate-pulse" />
            <span className="text-xs sm:text-sm font-mono font-bold tracking-widest text-sky-100 uppercase">
              WAITING: NODE STREAM
            </span>
          </div>
        </div>
      )}

      {/* LOADING STATE */}
      {loadingMeta && (
        <div className="z-10 flex flex-col items-center gap-3 bg-[#080d1a]/90 px-8 py-6 rounded-2xl border border-sky-500/40 backdrop-blur-md shadow-2xl">
          <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
          <span className="text-xs font-mono font-bold text-sky-200 tracking-wider">
            FETCHING OFFICIAL STREAM DATA...
          </span>
        </div>
      )}

      {/* ACTIVE VIDEO / DUB JOB DISPLAY */}
      {videoInfo && !loadingMeta && (
        <div className="relative w-full h-full flex flex-col justify-between p-4 sm:p-6 bg-gradient-to-t from-black/90 via-slate-950/70 to-slate-900/60">
          {/* Top Info Header */}
          <div className="flex items-center justify-between gap-2 z-10">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 bg-cyan-950/80 border border-cyan-800 text-cyan-300 rounded-md text-[10px] font-mono font-bold">
                ID: {videoInfo.videoId}
              </span>
              <span className="px-2.5 py-1 bg-indigo-950/80 border border-indigo-800 text-indigo-300 rounded-md text-[10px] font-mono">
                {videoInfo.sourcePlatform}
              </span>
            </div>
            <span className="text-xs font-mono text-emerald-400 font-bold bg-emerald-950/80 px-2.5 py-1 rounded-md border border-emerald-800/80">
              DURATION: {videoInfo.durationFormatted}
            </span>
          </div>

          {/* Center Title and Status */}
          <div className="my-auto text-center space-y-2 z-10 px-4">
            <h3 className="text-base sm:text-xl font-bold text-white line-clamp-2 drop-shadow-md">
              {videoInfo.title}
            </h3>
            {activeJob ? (
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-950/90 border border-indigo-500/50 rounded-full text-xs font-mono text-indigo-200 shadow-lg">
                <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                <span>Job Status: {activeJob.status} ({activeJob.overallProgressPercent}% Completed)</span>
              </div>
            ) : (
              <span className="text-xs text-sky-300 font-mono">
                Ready for Dubbing • Select Mode below to start
              </span>
            )}
          </div>

          {/* Bottom Progress Bar or Chunk Controller */}
          {activeJob && (
            <div className="z-10 space-y-2 bg-slate-950/80 p-3 rounded-xl border border-slate-800 backdrop-blur-sm">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-slate-300 font-semibold">Chunk Progress: {activeJob.currentChunkIndex}/{activeJob.totalChunks}</span>
                {activeJob.status !== 'COMPLETED' && (
                  <button
                    onClick={onProcessNextChunk}
                    disabled={isProcessingChunk}
                    className="px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded text-[11px] font-bold transition flex items-center gap-1"
                  >
                    {isProcessingChunk ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Play className="w-3 h-3 fill-white" />}
                    Process Chunk #{activeJob.currentChunkIndex + 1}
                  </button>
                )}
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-cyan-400 to-rose-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${activeJob.overallProgressPercent}%` }}
                />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
