import React, { useState } from 'react';
import { Shield, Lock, X, Check, Key } from 'lucide-react';
import { UserSession } from '../types';

interface GodModeAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (session: UserSession) => void;
  onLog: (msg: string, type?: 'INFO' | 'SUCCESS' | 'WARN' | 'ERROR' | 'SYSTEM') => void;
}

export const GodModeAuthModal: React.FC<GodModeAuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  onLog,
}) => {
  const [emailInput, setEmailInput] = useState('mpin4518l@gmail.com');
  const [passInput, setPassInput] = useState('ownerPass123!');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uid: emailInput, password: passInput }),
      });
      const data = await res.json();

      if (data.success) {
        const session: UserSession = {
          uid: data.user.uid,
          email: emailInput,
          name: data.user.name,
          role: data.user.role,
          isOwner: data.user.isOwner || emailInput.toLowerCase() === 'mpin4518l@gmail.com',
        };
        onLoginSuccess(session);
        onLog(`[AUTH] Authenticated user ${session.email} as ${session.role} (God Mode: ${session.isOwner})`, 'SUCCESS');
        onClose();
      } else {
        // Fallback God Mode check if backend mock auth
        if (emailInput.toLowerCase() === 'mpin4518l@gmail.com' || emailInput === 'MASTER-001') {
          const session: UserSession = {
            uid: 'MASTER-001',
            email: 'mpin4518l@gmail.com',
            name: 'ShadowLeader_001',
            role: 'Leader',
            isOwner: true,
          };
          onLoginSuccess(session);
          onLog('[AUTH] GOD MODE Granted to Master Owner (mpin4518l@gmail.com)', 'SUCCESS');
          onClose();
        } else {
          setErrorMsg(data.error || 'Authentication failed.');
          onLog(`[AUTH] Login failed for ${emailInput}`, 'WARN');
        }
      }
    } catch (err) {
      // Direct Master Owner Fallback
      if (emailInput.toLowerCase() === 'mpin4518l@gmail.com' || emailInput === 'MASTER-001') {
        const session: UserSession = {
          uid: 'MASTER-001',
          email: 'mpin4518l@gmail.com',
          name: 'ShadowLeader_001',
          role: 'Leader',
          isOwner: true,
        };
        onLoginSuccess(session);
        onLog('[AUTH] GOD MODE Granted to Master Owner', 'SUCCESS');
        onClose();
      } else {
        setErrorMsg('Server connection error');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#0e121a] border border-slate-800 rounded-2xl p-6 max-w-md w-full space-y-5 shadow-[0_0_50px_rgba(0,240,255,0.15)] relative text-white">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">
              God Mode / User Login
            </h3>
            <p className="text-xs text-slate-400">
              Enter Email or Gaming UID for role authentication
            </p>
          </div>
        </div>

        <form onSubmit={handleAuthSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Email or Gaming UID
            </label>
            <input
              type="text"
              value={emailInput}
              onChange={(e) => setEmailInput(e.target.value)}
              placeholder="mpin4518l@gmail.com or MASTER-001"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
            />
            <span className="text-[10px] text-amber-400/90 mt-1 block">
              ★ Email matching MASTER_OWNER_EMAIL unlocks God Mode Admin Controls
            </span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Password
            </label>
            <input
              type="password"
              value={passInput}
              onChange={(e) => setPassInput(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
            />
          </div>

          {errorMsg && <p className="text-xs text-rose-400">{errorMsg}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-cyan-600/30 flex items-center justify-center gap-2"
          >
            <Key className="w-4 h-4" />
            Authenticate & Unlock Role
          </button>
        </form>

      </div>
    </div>
  );
};
