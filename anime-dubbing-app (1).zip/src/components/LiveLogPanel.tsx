import React, { useRef, useEffect } from 'react';
import { Terminal, Trash2, Copy, Check } from 'lucide-react';
import { LogEntry } from '../types';

interface LiveLogPanelProps {
  logs: LogEntry[];
  onClearLogs: () => void;
}

export const LiveLogPanel: React.FC<LiveLogPanelProps> = ({ logs, onClearLogs }) => {
  const logEndRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = React.useState(false);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const handleCopy = () => {
    const text = logs.map(l => `[${l.timestamp}] [${l.type}] ${l.message}`).join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-2">
      {/* Live Log Header Row */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold text-white tracking-wide flex items-center gap-2">
          <Terminal className="w-4 h-4 text-cyan-400" />
          Live Log
        </h3>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition"
            title="Copy Logs to Clipboard"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={onClearLogs}
            className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-rose-400 transition"
            title="Clear Terminal Logs"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Solid Ultra-Black Terminal Box matching reference image */}
      <div className="w-full h-44 bg-black border border-slate-800/90 rounded-2xl p-4 font-mono text-[11px] overflow-y-auto space-y-1 shadow-2xl selection:bg-cyan-500 selection:text-black">
        {logs.length === 0 ? (
          <div className="text-slate-600 italic">Waiting for backend & engine events...</div>
        ) : (
          logs.map((log) => (
            <div key={log.id} className="flex items-start gap-2 leading-relaxed">
              <span className="text-slate-500 shrink-0">[{log.timestamp}]</span>
              <span
                className={`font-bold shrink-0 ${
                  log.type === 'SUCCESS'
                    ? 'text-emerald-400'
                    : log.type === 'WARN'
                    ? 'text-amber-400'
                    : log.type === 'ERROR'
                    ? 'text-rose-400'
                    : log.type === 'SYSTEM'
                    ? 'text-cyan-400'
                    : 'text-slate-300'
                }`}
              >
                [{log.type}]
              </span>
              <span className="text-slate-200 break-all">{log.message}</span>
            </div>
          ))
        )}
        <div ref={logEndRef} />
      </div>
    </div>
  );
};
