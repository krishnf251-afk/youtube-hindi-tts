import React, { useState } from 'react';
import { Settings, Mic, Download, Shield, User, Check, RefreshCw, Radio } from 'lucide-react';
import { UserSession } from '../types';

interface HeaderProps {
  userSession: UserSession | null;
  onOpenAuthModal: () => void;
  onOpenSettings: () => void;
  urlInput: string;
  setUrlInput: (val: string) => void;
  onFetchMetadata: () => void;
  loadingMeta: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  userSession,
  onOpenAuthModal,
  onOpenSettings,
  urlInput,
  setUrlInput,
  onFetchMetadata,
  loadingMeta,
}) => {
  const [isListening, setIsListening] = useState(false);

  const handleMicClick = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert('Speech Recognition is not supported in this browser.');
      return;
    }

    try {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.lang = 'hi-IN';
      recognition.continuous = false;

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onerror = () => setIsListening(false);

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setUrlInput(transcript);
        setIsListening(false);
      };

      recognition.start();
    } catch (e) {
      setIsListening(false);
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-[#0A0C0F]/90 backdrop-blur-md border-b border-slate-800/80 px-4 py-3">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
        
        {/* TOP ROW: Profile Icon, Search Bar, Settings Gear */}
        <div className="w-full flex items-center justify-between gap-3">
          
          {/* User Profile Icon Button (Metallic Circle) */}
          <button
            onClick={onOpenAuthModal}
            className="group relative flex items-center justify-center w-11 h-11 rounded-full bg-gradient-to-br from-slate-300 via-slate-500 to-slate-800 p-0.5 shadow-[0_0_15px_rgba(255,255,255,0.15)] hover:scale-105 transition-all"
            title={userSession ? `User: ${userSession.email} (${userSession.role})` : 'Click to Login / God Mode'}
          >
            <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center overflow-hidden border border-slate-600">
              <User className={`w-6 h-6 ${userSession?.isOwner ? 'text-amber-400' : 'text-slate-300'}`} />
            </div>
            {userSession?.isOwner && (
              <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-amber-500 ring-2 ring-slate-950 text-[9px] font-bold text-black">
                ★
              </span>
            )}
          </button>

          {/* Search Bar Container */}
          <div className="flex-1 max-w-2xl relative flex items-center">
            <input
              type="text"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && onFetchMetadata()}
              placeholder="Paste YouTube URL or Video ID"
              className="w-full bg-[#12161F] border border-slate-700/80 rounded-full py-2.5 pl-5 pr-20 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/50 shadow-inner"
            />
            
            {/* Mic Speech-to-Text Button inside Search Input */}
            <button
              onClick={handleMicClick}
              type="button"
              className={`absolute right-12 p-1.5 rounded-full transition ${
                isListening ? 'bg-rose-500 text-white animate-bounce' : 'text-slate-400 hover:text-white'
              }`}
              title="Speech-to-Text Mic Input"
            >
              <Mic className="w-4 h-4" />
            </button>

            {/* Submit / Fetch Arrow Icon */}
            <button
              onClick={onFetchMetadata}
              disabled={loadingMeta}
              className="absolute right-2.5 p-1.5 rounded-full bg-cyan-600 hover:bg-cyan-500 text-white disabled:opacity-50 transition shadow"
              title="Fetch Video Stream Data"
            >
              {loadingMeta ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
            </button>
          </div>

          {/* Settings Gear & Source ZIP Buttons */}
          <div className="flex items-center gap-2.5 shrink-0">
            <a
              href="/api/download-project-zip"
              download="anime_dubbing_app.zip"
              className="hidden sm:flex items-center gap-1.5 px-3.5 py-2.5 bg-[#12161F] hover:bg-slate-800 border border-slate-700/80 text-slate-200 rounded-full text-xs font-medium transition shadow-sm"
              title="Download Full Project Source (.ZIP)"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-[11px] font-mono">.ZIP</span>
            </a>

            <button
              onClick={onOpenSettings}
              className="flex items-center justify-center w-11 h-11 rounded-full bg-[#12161F] hover:bg-slate-800 border border-slate-700/80 text-slate-300 hover:text-white transition shadow-[0_0_12px_rgba(0,0,0,0.6)] hover:border-cyan-500/50 shrink-0"
              title="VIP Settings Drawer"
            >
              <Settings className="w-5 h-5 text-slate-300 group-hover:rotate-45 transition-transform duration-300" />
            </button>
          </div>
        </div>

        {/* STATUS SUB-BAR BELOW SEARCH (Matching reference screenshot) */}
        <div className="flex items-center justify-center gap-2 text-[11px] font-mono text-emerald-400 font-semibold tracking-wider">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>[GREEN] STATUS: ACTIVE</span>
          {userSession && (
            <span className="ml-3 text-slate-400 font-sans font-normal">
              • Signed as <strong className="text-cyan-300">{userSession.email}</strong> ({userSession.role})
            </span>
          )}
        </div>

      </div>
    </header>
  );
};
