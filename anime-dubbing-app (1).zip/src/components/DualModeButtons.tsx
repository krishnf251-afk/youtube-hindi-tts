import React, { useState } from 'react';
import { Zap, Sparkles, Mic, AlertCircle, Check, X } from 'lucide-react';

interface DualModeButtonsProps {
  selectedVoice: string;
  onSelectVoice: (voice: string) => void;
  onTriggerFastMode: () => void;
  onTriggerProMode: () => void;
  isProcessing: boolean;
}

export const DualModeButtons: React.FC<DualModeButtonsProps> = ({
  selectedVoice,
  onSelectVoice,
  onTriggerFastMode,
  onTriggerProMode,
  isProcessing,
}) => {
  const [showProConfirm, setShowProConfirm] = useState(false);

  const voices = [
    { id: 'hi-IN-MadhurNeural', name: 'Madhur (Male - Hindi)' },
    { id: 'hi-IN-SwaraNeural', name: 'Swara (Female - Hindi)' },
    { id: 'villain-demon', name: 'Demon / Villain (Pitch 0.8x)' },
    { id: 'waifu-heroine', name: 'Waifu / Heroine (Pitch 1.15x)' },
    { id: 'cute-child', name: 'Cute Child Ninja (Pitch 1.3x)' },
    { id: 'custom-clone', name: 'Custom Voice Clone (VIP Studio)' },
  ];

  const handleProModeClick = () => {
    setShowProConfirm(true);
  };

  const confirmProMode = () => {
    setShowProConfirm(false);
    onTriggerProMode();
  };

  return (
    <div className="space-y-4">
      {/* Start Dubbing Header Row with 2 Green Glowing Pills */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold text-white tracking-wide">
          Start Dubbing
        </h3>
        
        {/* Two Green Status Pills matching screenshot */}
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]" />
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400/60" />
        </div>
      </div>

      {/* Select Voice Pill Dropdown Container (Compact Glassmorphism) */}
      <div className="bg-[#10141D]/90 backdrop-blur-md border border-slate-800/90 rounded-xl p-2 flex items-center gap-2.5 shadow-xl">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-300 pl-2 shrink-0">
          <Mic className="w-3.5 h-3.5 text-cyan-400" />
          <span>Select Voice</span>
        </div>

        <select
          value={selectedVoice}
          onChange={(e) => onSelectVoice(e.target.value)}
          className="flex-1 bg-black/60 backdrop-blur-md border border-slate-800/80 rounded-lg px-2.5 py-1 text-[11px] text-cyan-100 focus:outline-none focus:border-cyan-500/80 font-sans cursor-pointer tracking-wide"
        >
          {voices.map((v) => (
            <option key={v.id} value={v.id} className="bg-[#0b0e14] text-slate-200 text-[11px] py-1">
              {v.name}
            </option>
          ))}
        </select>
      </div>

      {/* DUAL MODE FUTURISTIC CYBER BUTTONS (Matching Reference Image) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
        
        {/* FAST MODE (Radioactive Neon Cyan Glow) */}
        <button
          onClick={onTriggerFastMode}
          disabled={isProcessing}
          style={{
            boxShadow: '0 0 25px 5px rgba(0, 240, 255, 0.6), inset 0 0 15px rgba(0, 240, 255, 0.3)'
          }}
          className="relative group overflow-hidden h-16 rounded-2xl bg-gradient-to-r from-cyan-950 via-sky-900 to-cyan-950 border-2 border-cyan-400 hover:border-cyan-300 transition-all duration-300 flex items-center justify-center gap-3 active:scale-[0.98] disabled:opacity-50 cursor-pointer"
        >
          {/* Inner Cyan Pulse Overlay */}
          <div className="absolute inset-0 bg-cyan-400/10 group-hover:bg-cyan-400/25 transition-colors pointer-events-none" />
          
          <div className="p-1.5 rounded-lg bg-cyan-500/30 border border-cyan-400 text-cyan-300 shadow-[0_0_15px_#00f0ff]">
            <Zap className="w-5 h-5 fill-cyan-300 text-cyan-300" />
          </div>

          <span className="text-base sm:text-lg font-extrabold tracking-wider text-cyan-100 drop-shadow-[0_0_12px_rgba(0,240,255,0.9)]">
            Fast Mode
          </span>
        </button>

        {/* PRO MODE (Radioactive Crimson Red Glow) */}
        <button
          onClick={handleProModeClick}
          disabled={isProcessing}
          style={{
            boxShadow: '0 0 25px 5px rgba(244, 63, 94, 0.65), inset 0 0 15px rgba(244, 63, 94, 0.3)'
          }}
          className="relative group overflow-hidden h-16 rounded-2xl bg-gradient-to-r from-rose-950 via-red-900 to-rose-950 border-2 border-rose-500 hover:border-rose-400 transition-all duration-300 flex items-center justify-center gap-3 active:scale-[0.98] disabled:opacity-50 cursor-pointer"
        >
          {/* Inner Red Pulse Overlay */}
          <div className="absolute inset-0 bg-rose-500/10 group-hover:bg-rose-500/25 transition-colors pointer-events-none" />
          
          <div className="p-1.5 rounded-lg bg-rose-500/30 border border-rose-400 text-rose-300 shadow-[0_0_15px_#f43f5e]">
            <Sparkles className="w-5 h-5 fill-rose-300 text-rose-300" />
          </div>

          <span className="text-base sm:text-lg font-extrabold tracking-wider text-rose-100 drop-shadow-[0_0_12px_rgba(244,63,94,0.9)]">
            Pro Mode
          </span>
        </button>

      </div>

      {/* PRO MODE CONFIRMATION MODAL */}
      {showProConfirm && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0e121a] border border-rose-500/50 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-[0_0_50px_rgba(244,63,94,0.3)] relative">
            <button
              onClick={() => setShowProConfirm(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 text-rose-400">
              <AlertCircle className="w-6 h-6" />
              <h3 className="text-base font-bold text-white">
                Confirm Pro Mode Dubbing?
              </h3>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Pro Mode performs <strong>Full MP4 Rendering</strong> with Gemini Pro translation, full lip-sync audio alignment, and FFmpeg video remuxing into 4-minute chunks.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setShowProConfirm(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={confirmProMode}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-rose-600/40 flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                Yes, Start Pro Mode
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
