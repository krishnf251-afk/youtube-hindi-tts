import React from 'react';
import { Volume2, Mic, VolumeX } from 'lucide-react';
import { AudioMixerState } from '../types';

interface AudioMixingCardProps {
  audioMixer: AudioMixerState;
  onChangeAudioMixer: (updated: AudioMixerState) => void;
}

export const AudioMixingCard: React.FC<AudioMixingCardProps> = ({
  audioMixer,
  onChangeAudioMixer,
}) => {
  const toggleMaster = () => {
    onChangeAudioMixer({
      ...audioMixer,
      enabled: !audioMixer.enabled,
    });
  };

  const handleOrigChange = (v: number) => {
    onChangeAudioMixer({ ...audioMixer, origVol: v });
  };

  const handleDubChange = (v: number) => {
    onChangeAudioMixer({ ...audioMixer, dubVol: v });
  };

  const handleBgmChange = (v: number) => {
    onChangeAudioMixer({ ...audioMixer, bgmVol: v });
  };

  return (
    <div className="bg-[#10141D] border border-slate-800/90 rounded-2xl p-5 space-y-4 shadow-xl relative">
      {/* Header Row with Master Toggle */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
        <h3 className="text-sm font-bold text-white tracking-wide">
          Audio Mixing
        </h3>

        {/* Master Toggle Switch */}
        <button
          onClick={toggleMaster}
          className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors duration-300 ${
            audioMixer.enabled ? 'bg-cyan-500' : 'bg-slate-700'
          }`}
          title={audioMixer.enabled ? 'Audio Mixing Enabled' : 'Audio Mixing Muted'}
        >
          <div
            className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform duration-300 ${
              audioMixer.enabled ? 'translate-x-5' : 'translate-x-0'
            }`}
          />
        </button>
      </div>

      {/* Sliders Container */}
      <div className={`space-y-3.5 transition-opacity duration-300 ${audioMixer.enabled ? 'opacity-100' : 'opacity-40 pointer-events-none'}`}>
        
        {/* 1. Original Video Audio Slider (Cyan Accent) */}
        <div className="space-y-1">
          <div className="flex justify-between items-center text-xs">
            <span className="text-cyan-400 font-semibold flex items-center gap-1.5">
              <Volume2 className="w-3.5 h-3.5" />
              Original Video Audio
            </span>
            <span className="text-[10px] font-mono text-slate-400">{audioMixer.origVol}%</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            value={audioMixer.origVol}
            onChange={(e) => handleOrigChange(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
          />
        </div>

        {/* 2. Dubbed Audio Slider (Red Accent) */}
        <div className="space-y-1">
          <div className="flex justify-between items-center text-xs">
            <span className="text-rose-400 font-semibold flex items-center gap-1.5">
              <Mic className="w-3.5 h-3.5" />
              Dubbed Audio
            </span>
            <span className="text-[10px] font-mono text-slate-400">{audioMixer.dubVol}%</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            value={audioMixer.dubVol}
            onChange={(e) => handleDubChange(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-500"
          />
        </div>

        {/* 3. Background Music Slider (Glowing Bright Crimson Accent) */}
        <div className="space-y-1">
          <div className="flex justify-between items-center text-xs">
            <span className="text-red-400 font-semibold flex items-center gap-1.5 drop-shadow-[0_0_6px_rgba(239,68,68,0.5)]">
              <VolumeX className="w-3.5 h-3.5 text-red-400" />
              Background Music
            </span>
            <span className="text-[10px] font-mono text-red-300 font-bold">{audioMixer.bgmVol}%</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            value={audioMixer.bgmVol}
            onChange={(e) => handleBgmChange(Number(e.target.value))}
            className="w-full h-1.5 bg-red-950/60 rounded-lg appearance-none cursor-pointer accent-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)] border border-red-800/50"
          />
        </div>

      </div>
    </div>
  );
};
