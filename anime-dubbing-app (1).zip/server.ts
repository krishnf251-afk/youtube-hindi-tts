import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';

import { authenticateUser, getAllUsers, UserRole } from './src/server/auth';
import { fetchVideoInfoBypass } from './src/server/bypass';
import { analyzeAndTranslateAnimeScript } from './src/server/aiEngine';
import { createDubbingJob, processNextChunk, getJobStatus, processInstantVoiceChanger } from './src/server/dubbingEngine';
import { checkCacheByFingerprintOrId, saveCompletedJobToCache, createShareToken } from './src/server/cacheSharing';
import { addScheduledDubTask, getScheduledQueue, calculateServerLoad, run12HourAutoCleaner } from './src/server/automation';
import { triggerBackupSync, getBackupStatus, triggerEmergencyEscapeRollback } from './src/server/backupEscape';
import { getSurveillanceLogs, getErrorLogs, logError, logSurveillance } from './src/server/logger';
import { getOnboardingAnswer } from './src/server/onboardingBot';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middlewares
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // Request logger middleware for surveillance
  app.use((req, res, next) => {
    if (req.path.startsWith('/api/')) {
      const uid = (req.headers['x-user-uid'] as string) || 'GUEST';
      const role = (req.headers['x-user-role'] as string) || 'Common User';
      logSurveillance({
        uid,
        role,
        ip: req.ip || req.socket.remoteAddress,
        action: `${req.method} ${req.path}`,
        status: 'RECEIVED',
      });
    }
    next();
  });

  // --- API ENDPOINTS ---

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', serverTime: new Date().toISOString() });
  });

  // 1. Auth Login (Master Lock UID & Password)
  app.post('/api/auth/login', (req, res) => {
    try {
      const { uid, password } = req.body;
      const user = authenticateUser(uid, password);
      if (!user) {
        return res.status(401).json({ success: false, error: 'गलत गेमिंग UID या पासवर्ड!' });
      }
      res.json({
        success: true,
        user: {
          uid: user.uid,
          name: user.name,
          role: user.role,
          isOwner: user.isOwner || false,
        },
      });
    } catch (err) {
      logError(err, 'AUTH_LOGIN');
      res.status(500).json({ success: false, error: 'सर्वर एरर' });
    }
  });

  // Get Guild Users (Admin / Leader only)
  app.get('/api/auth/users', (req, res) => {
    res.json({ success: true, users: getAllUsers() });
  });

  // 2. Fetch Video Metadata & Bypass Third-Party YouTube Block (User Confirmation step)
  app.post('/api/fetch-info', async (req, res) => {
    try {
      const { url } = req.body;
      if (!url) return res.status(400).json({ success: false, error: 'URL आवश्यक है!' });

      const videoInfo = await fetchVideoInfoBypass(url);

      // Feature 11 & 13: Check double-tier cache by video ID or Fingerprint
      const cachedJob = checkCacheByFingerprintOrId(videoInfo.fingerprint);

      res.json({
        success: true,
        videoInfo,
        isCached: !!cachedJob,
        cachedJob,
      });
    } catch (err) {
      logError(err, 'FETCH_INFO');
      res.status(500).json({ success: false, error: 'थर्ड-पार्टी एपीआई से वीडियो प्राप्त करने में विफलता।' });
    }
  });

  // 3. Create Dubbing Job (Mode A: MP4 Download + Full Dubbing, Mode B: Audio Only Dubbing)
  app.post('/api/create-dub-job', async (req, res) => {
    try {
      const { videoInfo, mode, sourceLang, targetLang, scriptInput } = req.body;
      const uid = (req.headers['x-user-uid'] as string) || 'GUEST';
      const role = ((req.headers['x-user-role'] as string) as UserRole) || 'Common User';

      if (!videoInfo || !mode) {
        return res.status(400).json({ success: false, error: 'Missing parameters' });
      }

      // Perform AI Analysis & Translation (Fast Mode vs Pro Mode based on role)
      const analysis = await analyzeAndTranslateAnimeScript(
        scriptInput || videoInfo.title || 'Anime Episode',
        role,
        sourceLang || 'auto',
        targetLang || 'Hindi (हिंदी)'
      );

      // Create Job
      const job = createDubbingJob(uid, role, mode, videoInfo, analysis);

      res.json({
        success: true,
        job,
      });
    } catch (err) {
      logError(err, 'CREATE_DUB_JOB');
      res.status(500).json({ success: false, error: 'डबिंग जॉब बनाने में त्रुटि' });
    }
  });

  // 4. Process Next Chunk (Smart Chunking Feature 15)
  app.post('/api/process-chunk', async (req, res) => {
    try {
      const { jobId } = req.body;
      if (!jobId) return res.status(400).json({ success: false, error: 'Missing jobId' });

      const updatedJob = await processNextChunk(jobId);
      if (!updatedJob) return res.status(404).json({ success: false, error: 'Job not found' });

      if (updatedJob.status === 'COMPLETED') {
        saveCompletedJobToCache(updatedJob);
      }

      res.json({
        success: true,
        job: updatedJob,
      });
    } catch (err) {
      logError(err, 'PROCESS_CHUNK');
      res.status(500).json({ success: false, error: 'चंक प्रोसेसिंग में त्रुटि' });
    }
  });

  // 5. Get Job Status
  app.get('/api/job-status/:jobId', (req, res) => {
    const job = getJobStatus(req.params.jobId);
    if (!job) return res.status(404).json({ success: false, error: 'Job not found' });
    res.json({ success: true, job });
  });

  // 6. Instant Voice Changer API (Feature 22)
  app.post('/api/instant-voice-changer', (req, res) => {
    try {
      const { text, targetRole, emotion } = req.body;
      if (!text) return res.status(400).json({ success: false, error: 'Text required' });

      const result = processInstantVoiceChanger(text, targetRole || 'Hero', emotion || 'Action');
      res.json({ success: true, result });
    } catch (err) {
      logError(err, 'INSTANT_VOICE_CHANGER');
      res.status(500).json({ success: false, error: 'Voice conversion failed' });
    }
  });

  // 7. Smart Video Sharing (Feature 12)
  app.post('/api/share-dub', (req, res) => {
    try {
      const { jobId, receiverUid } = req.body;
      const senderUid = (req.headers['x-user-uid'] as string) || 'GUEST';

      const shareData = createShareToken(jobId, senderUid, receiverUid || 'ALL_MEMBERS');
      res.json({ success: true, shareData });
    } catch (err) {
      logError(err, 'SHARE_DUB');
      res.status(500).json({ success: false, error: 'शेयरिंग एरर' });
    }
  });

  // 8. Auto-Scheduler Task Queue (Feature 23)
  app.post('/api/schedule-dub', (req, res) => {
    try {
      const { url, mode, delayMinutes } = req.body;
      const addedBy = (req.headers['x-user-uid'] as string) || 'GUEST';

      const task = addScheduledDubTask(url, mode || 'MODE_B_AUDIO_ONLY', addedBy, delayMinutes || 1);
      res.json({ success: true, task });
    } catch (err) {
      logError(err, 'SCHEDULE_DUB');
      res.status(500).json({ success: false, error: 'Schedule failed' });
    }
  });

  app.get('/api/schedule-queue', (req, res) => {
    res.json({ success: true, queue: getScheduledQueue() });
  });

  // 9. Server Load / Traffic Indicator API (Feature 25)
  app.get('/api/server-load', (req, res) => {
    const loadInfo = calculateServerLoad();
    res.json({ success: true, loadInfo });
  });

  // 10. GitHub-HF Backup Sync & Emergency Escape (Feature 1 & 2)
  app.post('/api/admin/backup-sync', (req, res) => {
    const adminUid = (req.headers['x-user-uid'] as string) || 'GUEST';
    const status = triggerBackupSync(adminUid);
    res.json({ success: true, status });
  });

  app.get('/api/admin/backup-status', (req, res) => {
    res.json({ success: true, status: getBackupStatus() });
  });

  app.post('/api/admin/emergency-escape', (req, res) => {
    const adminUid = (req.headers['x-user-uid'] as string) || 'GUEST';
    const result = triggerEmergencyEscapeRollback(adminUid, req.body.commitHash);
    res.json(result);
  });

  // 11. AI Surveillance Logs & Silent Error Logs (Feature 5 & 6)
  app.get('/api/admin/surveillance-logs', (req, res) => {
    const logs = getSurveillanceLogs(100);
    res.json({ success: true, logs });
  });

  app.get('/api/admin/error-logs', (req, res) => {
    const logs = getErrorLogs(100);
    res.json({ success: true, logs });
  });

  // 12. Manual 12h Cleaner Trigger (Feature 24)
  app.post('/api/admin/trigger-cleaner', (req, res) => {
    const result = run12HourAutoCleaner();
    res.json({ success: true, result });
  });

  // 13. AI Onboarding Bot (Feature 7)
  app.post('/api/onboard', async (req, res) => {
    try {
      const { query } = req.body;
      const userRole = (req.headers['x-user-role'] as string) || 'Common User';

      const answer = await getOnboardingAnswer(query || 'How to use Mode A and Mode B?', userRole);
      res.json({ success: true, answer });
    } catch (err) {
      logError(err, 'ONBOARD_API');
      res.status(500).json({ success: false, answer: 'गाइड बोट उत्तर देने में असमर्थ है।' });
    }
  });

  // 14. Download / Stream Output Media file
  app.get('/api/download-dub/:jobId', (req, res) => {
    const job = getJobStatus(req.params.jobId);
    res.json({
      success: true,
      jobId: req.params.jobId,
      title: job?.videoInfo.title || 'Anime Hindi Dub',
      mode: job?.mode || 'MODE_B_AUDIO_ONLY',
      engineUsed: job?.analysis.engineUsed || 'Fast Mode',
      bgmPreset: job?.bgmTrackName || 'Phonk Beat',
      downloadUrl: `https://example.com/stream/${req.params.jobId}.${job?.mode === 'MODE_A_FULL_MP4' ? 'mp4' : 'mp3'}`,
    });
  });

  // 15. Download full project source ZIP file
  app.get('/api/download-project-zip', (req, res) => {
    const zipPath = path.join(process.cwd(), 'anime_dubbing_app.zip');
    if (fs.existsSync(zipPath)) {
      res.download(zipPath, 'anime_dubbing_app.zip');
    } else {
      res.status(404).send('ZIP File not found');
    }
  });

  // --- VITE MIDDLEWARE (DEV) vs STATIC SERVING (PROD) ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Anime Dubbing Core Backend Engine running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  logError(err, 'SERVER_STARTUP');
  console.error('Fatal Server Error:', err);
});
