
# app.py
import os
import re
import uuid
import shutil
import tempfile
import asyncio
import traceback
from typing import List, Dict, Optional
from fastapi import FastAPI, Form, BackgroundTasks, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from youtube_transcript_api import YouTubeTranscriptApi, TranscriptsDisabled, NoTranscriptFound
import requests
from dotenv import load_dotenv

# TTS and audio libs
from edge_tts import Communicate
from pydub import AudioSegment

load_dotenv()

# ---------- Configuration ----------
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")  # required
GEMINI_API_URL = os.getenv("GEMINI_API_URL")  # required; user-provided translate endpoint
OUTPUT_DIR = os.getenv("OUTPUT_DIR", "./outputs")
VOICE = os.getenv("TTS_VOICE", "hi-IN-MadhurNeural")
BITRATE = os.getenv("MP3_BITRATE", "128k")

os.makedirs(OUTPUT_DIR, exist_ok=True)

# In-memory job store (keeps tiny state only)
JOBS = {}  # job_id -> {status, message, output_path or error}

app = FastAPI(title="Lightweight YouTube Transcript → Hindi TTS (no-download)")

# ---------- Helpers ----------

def extract_video_id(url_or_id: str) -> str:
    if re.match(r'^[A-Za-z0-9_-]{11}$', url_or_id):
        return url_or_id
    m = re.search(r'(?:v=|\/)([A-Za-z0-9_-]{11})', url_or_id)
    if m:
        return m.group(1)
    return url_or_id

def fetch_transcript_segments(video_url_or_id: str, languages: Optional[List[str]] = None) -> List[Dict]:
    vid = extract_video_id(video_url_or_id)
    if languages is None:
        languages = ['en', 'ja', 'zh', 'ko', 'auto']
    try:
        transcript_list = YouTubeTranscriptApi.list_transcripts(vid)
        transcript = None
        for lang in languages:
            try:
                transcript = transcript_list.find_transcript([lang])
                break
            except Exception:
                continue
        if transcript is None:
            available = [t.language_code for t in transcript_list._transcripts] if hasattr(transcript_list, "_transcripts") else []
            if available:
                transcript = transcript_list.find_transcript([available[0]])
        if transcript is None:
            raise NoTranscriptFound(vid)
        fetched = transcript.fetch()
        normalized = []
        for seg in fetched:
            normalized.append({
                'start': float(seg.get('start', 0.0)),
                'duration': float(seg.get('duration', 0.0)),
                'text': seg.get('text', '').strip()
            })
        if not normalized:
            raise NoTranscriptFound(vid)
        return normalized
    except (TranscriptsDisabled, NoTranscriptFound) as e:
        raise e
    except Exception as e:
        raise e

def translate_text_with_gemini(text: str) -> str:
    if not GEMINI_API_URL or not GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_URL and GEMINI_API_KEY must be set in environment.")
    headers = {
        "Authorization": f"Bearer {GEMINI_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {"input": text, "target_language": "hi"}
    try:
        resp = requests.post(GEMINI_API_URL, json=payload, headers=headers, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        if isinstance(data, dict):
            if "translated_text" in data:
                return data["translated_text"]
            if "translation" in data:
                return data["translation"]
            if "output" in data and isinstance(data["output"], str):
                return data["output"]
        if isinstance(data, str):
            return data
        raise RuntimeError(f"Unexpected Gemini response shape: {data}")
    except Exception as e:
        raise RuntimeError(f"Gemini translation failed: {str(e)}")

async def synthesize_text_to_file_async(text: str, out_path: str, voice: str = VOICE):
    comm = Communicate(text, voice)
    await comm.save(out_path)

def synthesize_and_align(chunks: List[Dict], tmpdir: str, job_id: str) -> str:
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    parts = []
    try:
        for i, c in enumerate(chunks):
            original_text = c.get('text', '').strip()
            start = float(c.get('start', 0.0))
            duration = float(c.get('duration', 0.0))
            if original_text:
                translated = translate_text_with_gemini(original_text)
            else:
                translated = ""

            if translated:
                part_path = os.path.join(tmpdir, f"tts_part_{i}.mp3")
                loop.run_until_complete(synthesize_text_to_file_async(translated, part_path))
                parts.append({'path': part_path, 'start': start, 'duration': duration})
            else:
                parts.append({'path': None, 'start': start, 'duration': duration})
            JOBS[job_id]['message'] = f"synthesized_segment_{i}"
    except Exception as e:
        raise

    final = None
    for p in parts:
        start_ms = int(round(p['start'] * 1000))
        if final is None:
            final = AudioSegment.silent(duration=max(0, start_ms))
        else:
            if len(final) < start_ms:
                gap = start_ms - len(final)
                final += AudioSegment.silent(duration=gap)
        if p['path']:
            seg = AudioSegment.from_file(p['path'], format="mp3")
            final += seg
            try:
                os.remove(p['path'])
            except Exception:
                pass
        else:
            dur_ms = int(round(p.get('duration', 0.0) * 1000))
            if dur_ms > 0:
                final += AudioSegment.silent(duration=dur_ms)

    if final is None:
        final = AudioSegment.silent(duration=1000)

    out_mp3 = os.path.join(tmpdir, "final_audio.mp3")
    final.export(out_mp3, format="mp3", bitrate=BITRATE)
    return out_mp3

def ensure_audio_length(final_mp3_path: str, expected_duration_sec: Optional[float]):
    audio = AudioSegment.from_file(final_mp3_path, format="mp3")
    duration_ms = len(audio)
    if expected_duration_sec is not None:
        expected_ms = int(round(expected_duration_sec * 1000))
        if duration_ms < expected_ms:
            pad_ms = expected_ms - duration_ms
            audio += AudioSegment.silent(duration=pad_ms)
            audio.export(final_mp3_path, format="mp3", bitrate=BITRATE)
            duration_ms = expected_ms
    return duration_ms / 1000.0

def process_video_task(video_url: str, job_id: str):
    JOBS[job_id] = {"status": "started", "message": "queued", "output": None, "error": None}
    tmpdir = None
    try:
        JOBS[job_id]['status'] = "fetching_transcript"
        JOBS[job_id]['message'] = "fetching_transcript"
        segments = fetch_transcript_segments(video_url)
        JOBS[job_id]['status'] = "transcript_fetched"
        JOBS[job_id]['message'] = f"segments:{len(segments)}"

        tmpdir = tempfile.mkdtemp(prefix="vt_")
        JOBS[job_id]['message'] = "synthesizing_tts"
        final_mp3 = synthesize_and_align(segments, tmpdir, job_id)

        JOBS[job_id]['message'] = "ensuring_length"
        last_seg = segments[-1]
        expected = last_seg['start'] + last_seg['duration']
        actual_sec = ensure_audio_length(final_mp3, expected)

        out_name = f"{job_id}.mp3"
        out_path = os.path.join(OUTPUT_DIR, out_name)
        shutil.move(final_mp3, out_path)

        JOBS[job_id]['status'] = "done"
        JOBS[job_id]['message'] = f"ready length={actual_sec:.2f}s"
        JOBS[job_id]['output'] = out_path
        return
    except Exception as e:
        tb = traceback.format_exc()
        JOBS[job_id]['status'] = "error"
        JOBS[job_id]['error'] = str(e)
        JOBS[job_id]['message'] = f"error:{str(e)}"
        print("PROCESS ERROR:", str(e))
        print(tb)
    finally:
        try:
            if tmpdir and os.path.isdir(tmpdir):
                shutil.rmtree(tmpdir)
        except Exception:
            pass

from fastapi import FastAPI, Form, BackgroundTasks, HTTPException
from fastapi.responses import FileResponse, JSONResponse
import uuid
import threading

app = FastAPI(title="Lightweight YouTube Transcript → Hindi TTS (no-download)")

@app.post("/process/")
async def process_endpoint(video_url: str = Form(...), background_tasks: BackgroundTasks = None):
    job_id = uuid.uuid4().hex[:16]
    JOBS[job_id] = {"status": "queued", "message": "job_created", "output": None, "error": None}
    if background_tasks is not None:
        background_tasks.add_task(process_video_task, video_url, job_id)
    else:
        t = threading.Thread(target=process_video_task, args=(video_url, job_id), daemon=True)
        t.start()
    return {"job_id": job_id, "status_url": f"/status/{job_id}", "output_url": f"/output/{job_id}"}

@app.get("/status/{job_id}")
def status(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="job not found")
    return {"job_id": job_id, "status": job.get("status"), "message": job.get("message"), "error": job.get("error")}

@app.get("/output/{job_id}")
def output(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="job not found")
    if job.get("status") != "done" or not job.get("output"):
        raise HTTPException(status_code=400, detail="output not ready")
    return FileResponse(job["output"], media_type="audio/mpeg", filename=os.path.basename(job["output"]))

@app.get("/")
def root():
    return JSONResponse({"info": "Lightweight transcript->translate->TTS service. POST /process/ with form field video_url."})
